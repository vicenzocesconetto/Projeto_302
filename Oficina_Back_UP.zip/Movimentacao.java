public abstract class Movimentacao {
	private float valor;

	public Movimentacao(float valor) {
		this.valor = valor;
	}
	public float getValor() {
		return valor;
	}
	public void setValor(float valor) {
		this.valor = valor;
	}	
}
