
public enum Cargo {
	ATENDENTE, GERENTE
}
