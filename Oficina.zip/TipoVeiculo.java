public enum TipoVeiculo {
	CARRO, MOTO, CAMINHAO
}
