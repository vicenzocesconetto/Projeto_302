public interface PrettyPrint {
    public String prettyPrint();
}
